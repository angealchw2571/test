package accounts

import (
	"encoding/json"
	"fmt"
	"log"
	"net/http"

	"github.com/julienschmidt/httprouter"
)

type sAccountDetails struct {
	Name     string `json:"name"`
	Password string `json:"password"`
	Email    string `json:"email"`
	Deleted  bool   `json:"deleted"`
}

func APIGetAccount(w http.ResponseWriter, r *http.Request, ps httprouter.Params) {
	userid := ps.ByName("name")
	// fmt.Println("GET request: RESTGetAccount - ", userid)

	rname, rpassword, remail, rdeleted, rerr := GetAccountByName(userid)
	fmt.Printf("%s\t|%s\t|%s\t|%t\n", rname, rpassword, remail, rdeleted)

	if rerr != nil {
		fmt.Printf("error occurred getting %s; %s", rname, rerr)
	}

	// data := &sAccountDetails{
	// 	Name:     rname,
	// 	Password: rpassword,
	// 	Email:    remail,
	// 	Deleted:  rdeleted}

	// dataJ, _ := json.Marshal(data)

	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(http.StatusOK)
	resp := make(map[string]string)
	resp["status"] = "Success"
	resp["statusCode"] = "200"
	resp["accname"] = rname
	resp["accpassword"] = rpassword
	resp["accemail"] = remail
	if rdeleted == true {
		resp["accdeleted"] = "true"
	} else {
		resp["accdeleted"] = "false"
	}
	jsonResp, err := json.Marshal(resp)
	if err != nil {
		log.Fatalf("Error happened in JSON marshal. Err: %s", err)
	}
	w.Write(jsonResp)
}
