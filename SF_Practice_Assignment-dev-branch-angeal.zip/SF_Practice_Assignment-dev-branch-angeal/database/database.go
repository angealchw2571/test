package main

import (
	"fmt"
	"log"
	"net/http"

	"accounts"
	"task"

	"github.com/joho/godotenv"
	"github.com/julienschmidt/httprouter"
)

func testDB_Accounts() {
	//test: accounts
	var dummy string = "pgx6"
	var dummy2 string = "pgxpgx"
	accounts.CreateAccount(dummy, dummy, "pgx@fake.com")
	accounts.GetAccountByName(dummy)
	accounts.UpdateAccountPassword(dummy, dummy2)
	accounts.DeleteAccount(dummy)
	accounts.GetAccountByName(dummy)
}

func testDB_Accounts_NonExistUser() {
	rname, rpassword, remail, rdeleted, rerr := accounts.GetAccountByName("sfvgewrvfvw")
	if rerr != nil {
		fmt.Printf("error getting account details of 'sfvgewrvfvw'.\n")
	}
	fmt.Printf("%s | %s | %s | %t\n", rname, rpassword, remail, rdeleted)
}

func testDB_Task() {
	var dummy string = "pgxtask1"
	var dummy2 string = "A task created using golang/pgx"
	var dummy3 string = "open"
	var dummy4 string = "todo"
	task.CreateTask(dummy, dummy, dummy3)
	rname, rid, rstate, rdescription, _ := task.GetTaskByID(dummy)
	fmt.Printf("%s | %s | %s | %s\n", rname, rid, rstate, rdescription)
	task.UpdateTaskDescription(dummy, dummy2)
	task.UpdateTaskState(dummy, dummy4)
	rname, rid, rstate, rdescription, _ = task.GetTaskByID(dummy)
	fmt.Printf("%s | %s | %s | %s\n", rname, rid, rstate, rdescription)
}

func main() {
	fmt.Printf("Loading environment variables...\n")
	enverr := godotenv.Load(".env")
	if enverr != nil {
		log.Fatalf("Error loading .env file\n")
	}
	fmt.Printf("Environment variables loaded.\n")

	accounts.AccountsEstablishConnection()
	defer accounts.AccountsClose()
	// testDB_Accounts()

	task.TaskEstablishConnection()
	defer task.TaskClose()
	// testDB_Task()

	router := httprouter.New()
	router.GET("/api/getuser/:name", accounts.APIGetAccount)
	fmt.Printf("dbServer listening at port 8088.\n")
	log.Fatal(http.ListenAndServe(":8088", router))
}
