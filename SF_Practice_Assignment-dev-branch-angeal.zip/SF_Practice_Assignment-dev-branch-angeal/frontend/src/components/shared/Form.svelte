<script>
	//Imported packages
	import { createEventDispatcher } from 'svelte';
	import Button from './Button.svelte';
	//Exported variables to pass values down to this component.
	export let action = 'get';
	export let inputs = [];
	
    // export let id;
	// export let type = 'text';
	// export let value = '';
	// export let label;

	const handleInput = (event,input) => {
		input.value = event.target.type === 'checkbox' ? event.target.checked : event.target.value;
        //console.log(input.value);
	};
	//dispatch variable to hold method.
	const dispatch = createEventDispatcher();

    const submitHandler = (e) => {
        console.log(e.target.CHICKEN);
    }

</script>

<form on:submit|preventDefault={submitHandler}>
	{#each inputs as input}
		<div class="form-field">
			<label for={input.id}>{input.label}: {input.value}</label>
			<input
				id={input.id}
				type={input.type}
				value={input.value}
                name={"CHICKEN"}
				on:input={(event) => handleInput(event, input)}
				on:change={(event) => handleInput(event, input)}
			/>
			<div class="error">{input.error}</div>
		</div>
	{/each}
	<Button type="secondary" flat="true">Login</Button>
</form>

<style>
	form {
		width: 400px;
		margin: 0 auto;
		text-align: center;
	}

	.form-field {
		margin: 18px auto;
	}

	input {
		width: 100%;
		border-radius: 6px;
	}

	label {
		margin: 10px auto;
		text-align: left;
	}

	.error {
		font-weight: bold;
		font-size: 12px;
		color: #d91b42;
	}
</style>
