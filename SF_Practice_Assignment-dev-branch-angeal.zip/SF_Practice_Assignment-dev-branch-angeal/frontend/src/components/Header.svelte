<header>
    <h1>
        <img src="favicon.png" alt="Image">
    </h1>
</header>

<style>
    header {
        background: #f7f7f7;
        padding: 20px;

    }
    h1 {
        margin: 0;
        text-align: center;

    }
    img {
        max-width:180px;
    }
</style>