<footer>
    <div class="copyright">Copyright Team 1 Agile Squad</div>
</footer>

<style>
    footer {
        padding: 40px;
        text-align: center;
    }
    .copyright {
        color:#aaa;
        font-size: 14px;
        display: inline-block;
        padding: 20px;
        border-top: 1px solid #ddd;
    }
</style>