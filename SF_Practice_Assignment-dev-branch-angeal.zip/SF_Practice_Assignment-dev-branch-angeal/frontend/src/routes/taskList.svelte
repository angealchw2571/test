<svelte:head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</svelte:head>

<script>
    import axios from 'axios';
    import { goto } from "$app/navigation";
    import { onMount } from 'svelte';

    let tasks;

    tasks = [ {
            "Id": "ALPHA_1",
            "taskname": "ALPHA",
            "description": "This is for Alpha",
            "state": "Done"
        },
        {
            "Id": "ABC_0",
            "taskname": "ABC",
            "description": "This is for ABC",
            "state": "Open"
        },
        {
            "Id": "BETA_2",
            "taskname": "BETA",
            "description": "This is for BETA",
            "state": "Close"
        }]
    let error = "";
    //console.log(tasks.map(x => Object.values(x)));
    onMount(async () => { 
        try {
        // const res = await axios.post(`http://localhost:8081/test`, {
        const res = await axios
            .get(`http://${import.meta.env.VITE_DOMAIN_NAME}:${import.meta.env.VITE_DOMAIN_PORT}/api/alltask`, {
                headers: {
                    Accept: '*/*',
                    'Content-Type': 'application/json'
                }
            })
        
        // console.log(res);
        // console.log(res.data)
        // console.log(res.data.Data)
        if(res.data.StatusCode == 200){
            console.log(res.data.Data);
            tasks=res.data.Data;
        } else {
            console.log("ELSE STATEMENT",res);
        }
        } catch (err) {
            error = "Username or password is incorrect."
            //console.log(err);
		}
    })
</script>

<button type="button" on:click={() => goto('/createTask')}>Create Task</button>
<h1><u>All Tasks</u></h1>

{#each tasks as task}
    <details>
        <summary>{Object.values(task)[0]}</summary>    
            {#each Object.entries(task) as [key, value], index (key)}      
                <p>{key} : {value}</p>     
            {/each}
        <p><a href="/editTask?{task.Id}">Edit</a></p>
    </details>
{/each}

<style>
button {
    background-color: pink;
    color: black;
    padding: 20px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
    margin: 4px 2px;
    cursor: pointer;
    border-radius: 12px;
}

details {
    font-size: 20px;
    border: 1px solid #d4d4d4;    
    padding: .75em .75em 0;
	margin-top: 10px;
	box-shadow:0 0 20px #d4d4d4;
}

summary {	
    font-weight: bold;
    margin: -.75em -.75em 0;
    padding: .75em;
    background-color: #5f75a4;
    color: #fff;
    font-family: Arial;
}

details[open] {
    padding: .75em;
	border-bottom: 1px solid #d4d4d4;
}

details[open] summary {
    border-bottom: 1px solid #d4d4d4;
    margin-bottom: 10px;
}
</style>
