<script>
    import NavBar from "../components/shared/NavBar.svelte";
    import TaskList from "./taskList.svelte";
</script>

<NavBar />
<TaskList />