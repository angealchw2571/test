<script>
    import axios from 'axios';
    import { goto } from "$app/navigation";
    import NavBar from '../components/shared/NavBar.svelte';

    //Variables
    let fields = { taskid: '', taskname: '', description: '', state: ''};
    let errors = { taskid: '', taskname: '', description: '', state: ''};
    let success = "";
  
    let valid = false;

    let tasks;

    tasks = [ {
        "Id": "ALPHA_1",
        "taskname": "ALPHA",
        "description": "This is for Alpha",
        "state": "Done"
    },
    {
        "Id": "ABC_0",
        "taskname": "ABC",
        "description": "This is for ABC",
        "state": "Open"
    },
    {
        "Id": "BETA_2",
        "taskname": "BETA",
        "description": "This is for BETA",
        "state": "Close"
    }]

  const submitHandler = async () => {
    //TODO need to add data and add backend endpoint
    valid = true;
    // validate task ID
    if (fields.taskid.trim().length === 0) {
      valid = false;
      errors.taskid = 'Task ID cannot be empty';
    } else {
      errors.taskid = '';
    }
    // validate task name
    if (fields.taskname.trim().length === 0) {
      valid = false;
      errors.taskname = 'Task name cannot be empty';
    } else {
      errors.taskname = '';
    }
    // validate task description
    if (fields.description.trim().length === 0) {
      valid = false;
      errors.description = 'Task description cannot be empty';
    } else {
      errors.description = '';
    }
    // validate task state
    if (fields.state.trim().length === 0) {
      valid = false;
      errors.state = 'Task state cannot be empty';
    } else {
      errors.state = '';
    }

    if (valid) {
      console.log(fields)
      //axios
      try {
          const res = await axios
            .post(`http://${import.meta.env.VITE_DOMAIN_NAME}:${import.meta.env.VITE_DOMAIN_PORT}/api/updatetask?{tasks.Id}`, fields, {
              headers: {
                Accept: '*/*',
                'Content-Type': 'application/json'
              }
            })
          
          if(res.status == 200)	{
            success = "Successfully updated a task."
          } else {
            console.log(res);
          }
      } catch (err) {console.log(err);}
    }
  }
</script>

<NavBar />
<div class="container">
    <h1>Edit Task</h1>
    <form on:submit|preventDefault={submitHandler}>
        <label for="taskid"><b>Task ID</b></label>
        <input type="text" placeholder="Task ID" name="taskid" id="taskid" bind:value={fields.taskid}>
        <span class="error">{ errors.taskid }</span><br>

        <label for="taskname"><b>Task Name</b></label>
        <input type="text" placeholder="Task Name" name="taskname" id="taskname" bind:value={fields.taskname}>
        <span class="error">{ errors.taskname }</span><br>

        <label for="description"><b>Task Description</b></label>
        <input type="text" placeholder="Description" name="description" id="description" bind:value={fields.description}>
        <span class="error">{ errors.description }</span><br>

        <label for="state"><b>Task State</b></label>
        <input type="text" name="state" id="state" bind:value={fields.state}>
        <span class="error">{ errors.state }</span><br>
        <div class="success">{ success }</div>

        <button type="submit" class="editbtn">Edit Task</button>
        <button type="button" on:click={() => goto('/dashboard')} class="backbtn">Back</button><br>
    </form>
</div>

<style>
.error {
  font-weight: bold;
  color: #d91b42;
}

.success {
  font-weight: bold;
  color: #45c496;
}

/* Add padding to containers */
.container {
  padding: 0;
  background-color: white;
}

/* Full-width input fields */
input[type=text] {
  width: 100%;
  padding: 15px;
  margin: 5px 0 22px 0;
  display: inline-block;
  border: none;
  background: #f1f1f1;
}

input[type=text]:focus {
  background-color: #ddd;
  outline: none;
}

/* Set a style for the submit button */
.editbtn {
  background-color: #04AA6D;
  color: white;
  padding: 16px 20px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 100%;
  opacity: 0.9;
}

/* Set a style for the back button */
.backbtn {
  background-color: black;
  color: white;
  padding: 16px 20px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 100%;
  opacity: 0.9;
}

.editbtn:hover, .backbtn:hover {
  opacity: 1;
}
</style>