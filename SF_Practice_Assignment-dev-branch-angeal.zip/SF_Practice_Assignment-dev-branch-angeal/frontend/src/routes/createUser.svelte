<script>
    //Packages
    import axios from 'axios';
    import { goto } from '$app/navigation';

    //Components
    import Navbar from '../components/shared/NavBar.svelte';
    
    //Variables
    let fields = { username: '', password: '', email: ''};
    let errors = { username: '', password: '', email: ''};
    let success = "";

    let valid = false;

    const submitHandler = async () => {
        valid = true;
        // validate username
        if (fields.username.trim().length === 0 ) {
            valid = false;
            errors.username = 'Username cannot be empty';
        } else {
            errors.username = '';
        }
        // validate password
        if (fields.password.trim().length === 0) {
            valid = false;
            errors.password = 'Password cannot be empty';
        } else {
            errors.password = '';
        }
        // validate email
        if (fields.email.trim().length === 0) {
            valid = false;
            errors.email = 'Email cannot be empty';
        } else {
            errors.email = '';
        }
    
        if(valid) {

            console.log(fields)
            //axios
            try {
                const res = await axios
                    .post(`http://${import.meta.env.VITE_DOMAIN_NAME}:${import.meta.env.VITE_DOMAIN_PORT}/api/createuser`, fields, {
                        headers: {
                            Accept: '*/*',
                            'Content-Type': 'application/json'
                        }
                    })

                if(res.status == 200) {
                    success = "Successfully created a new user."; 
                } else {
                    console.log(res);
                }

            } catch (err) {
                console.log(err.response.data.Message);
                if(err.response.data.Message.includes("Username")) {errors.username = err.response.data.Message;}
            }
        }
        
    }
</script>

<Navbar />
<div class="container">
    <h1>New User</h1>
    <form on:submit|preventDefault={submitHandler}>
        <label for="username"><b>Username</b></label>
        <input type="text" placeholder="Username" name="username" id="username" bind:value={fields.username}>
        <span class="error">{ errors.username }</span><br>
    
        <label for="password"><b>Password</b></label>
        <input type="password" placeholder="Password" name="password" id="password" maxLength=10 bind:value={fields.password}>
        <span class="error">{ errors.password }</span><br>
    
        <label for="email"><b>Email</b></label>
        <input type="text" placeholder="Email" name="email" id="email" bind:value={fields.email}>
        <span class="error">{ errors.email }</span><br>
        <div class="success">{ success }</div>
        <button type="submit" class="createbtn">Create New User</button>
        <button type="button" on:click={() => goto('/dashboard')} class="backbtn">Back</button><br>
    </form>
</div>

<style>
.error {
    font-weight: bold;
    color: #d91b42;
}

.success {
    font-weight: bold;
    color: #45c496;
}

/* Add padding to containers */
.container {
  padding: 16px;
  background-color: white;
}

/* Full-width input fields */
input[type=text], input[type=password] {
  width: 100%;
  padding: 15px;
  margin: 5px 0 22px 0;
  display: inline-block;
  border: none;
  background: #f1f1f1;
}

input[type=text]:focus, input[type=password]:focus {
  background-color: #ddd;
  outline: none;
}

/* Set a style for the submit button */
.createbtn {
  background-color: #04AA6D;
  color: white;
  padding: 16px 20px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 100%;
  opacity: 0.9;
}

/* Set a style for the back button */
.backbtn {
  background-color: black;
  color: white;
  padding: 16px 20px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 100%;
  opacity: 0.9;
}

.createbtn:hover, .backbtn:hover {
  opacity: 1;
}
</style>