package controllerUser

import (
	"bytes"
	"encoding/json"
	"fmt"

	response "example.com/packages/responseTemplates"
	"github.com/gorilla/sessions"
	// "golang.org/x/crypto/bcrypt"

	// "io/ioutil"
	"log"
	"net/http"
)


var store = sessions.NewCookieStore([]byte("testing"))

func initSession(w http.ResponseWriter, r *http.Request) {
	sess, _ := store.Get(r, "session-name") // session_name like: addmin_sess of user_ses or onything.
	sess.Options = &sessions.Options{
		Path:     "/",
		MaxAge:   1000, // = 1h,
		HttpOnly: true, // no websocket or any protocol else
	}

	sess.Values["username"] = "superman"
	sess.Values["email"] = "chicken"
	err := sess.Save(r, w)
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}
	return
}

func LoginHandler(w http.ResponseWriter, r *http.Request) {
	var cAccount Account
	err := json.NewDecoder(r.Body).Decode(&cAccount)
	if err != nil {
		fmt.Println("error", err)
		panic(err)
	}

	//? Fetching from DB

	urlString := DomainURL + "api/getuser/" + cAccount.Username
	resp, err := http.Get(urlString)
	if err != nil {
		log.Fatalln(err)
	}
	var respSingleUser MultiUserDB
	err = json.NewDecoder(resp.Body).Decode(&respSingleUser)
	if err != nil {
		panic(err)
	}

	if respSingleUser.Data[0].AccName == "" {
		response.BadResponse(w, r, "Failure to authenticate (ERR 3243DS)", "")
	} else if cAccount.Password == respSingleUser.Data[0].AccPassword {
		initSession(w, r)
		response.SuccessResponse(w, r, "Login Success", "")
	} else {
		fmt.Println("Incorrect password")
		response.BadResponse(w, r, "Failure to authenticate (ERR JHE24D)", "")
	}

	// hashedPassword, err := bcrypt.GenerateFromPassword([]byte(cAccount.Password), bcrypt.DefaultCost)
	// if err != nil {
	// 	panic(err)
	// }
	// fmt.Println("caccount.password", cAccount.Password)
	// fmt.Println("userinput hash pw", hashedPassword)
	// fmt.Println("db hash pw", []byte(dbAccount.AccPassword))
	// fmt.Println("userinput hash pw in string", string(hashedPassword))
	// fmt.Println("db hash pw", dbAccount.AccPassword)
	// fmt.Println(string(hashedPassword) == dbAccount.AccPassword)
	// hash1, _ := bcrypt.GenerateFromPassword([]byte("123456"), bcrypt.DefaultCost)
	// err = bcrypt.CompareHashAndPassword(hash1, []byte("123456"))
	// if err != nil {
	// 	log.Println(err)
	// } else {
	// 	log.Println("success")
	// }
	//? Password hashing
	// err = bcrypt.CompareHashAndPassword(hashedPassword, []byte(dbAccount.AccPassword))
	// if err != nil {
	// fmt.Println("Incorrect password", err)
	// response.BadResponse(w, r, "Failure to authenticate (ERR SDD3D)")
	// } else {
	// initSession(w, r)
	// response.SuccessResponse(w, r, "Login Success")
	// }

	//* 		Login
}

func CreateUserHandler(w http.ResponseWriter, r *http.Request) {
	var nAccount Account
	err := json.NewDecoder(r.Body).Decode(&nAccount)
	if err != nil {
		panic(err)
	}

	// nHashedPassword, err := bcrypt.GenerateFromPassword([]byte(nAccount.Password), bcrypt.DefaultCost)
	// if err != nil {
	// 	panic(err)
	// }

	urlString2 := DomainURL + "api/getuser/" + nAccount.Username
	var singleUser DBAccountData
	resp, err := http.Get(urlString2)
	if err != nil {
		log.Fatalln(err)
	}

	err = json.NewDecoder(resp.Body).Decode(&singleUser)
	if err != nil {
		panic(err)
	}

	if singleUser.AccName != "" {
		response.BadResponse(w, r, "Username exists", "")
	} else {
		urlString := DomainURL + "api/createuser"
		newUserValues := map[string]string{"name": nAccount.Username, "password": nAccount.Password, "email": nAccount.Email}
		json_data, err := json.Marshal(newUserValues)
		if err != nil {
			log.Fatal(err)
		}

		resp, err := http.Post(urlString, "application/json",
			bytes.NewBuffer(json_data))
		if err != nil {
			log.Fatalln(err)
			response.BadResponse(w, r, "Create User Failed (ERR 336TDM)", "")
		} else {
			fmt.Println(resp)
			response.SuccessResponse(w, r, "Create User Success", "")
		}

	}

	//* 		Create User
}

