package response

import (
	"encoding/json"
	"fmt"
	"log"
	"net/http"
)

type DBAccountData struct {
	AccName     string
	AccPassword string
	AccEmail    string
	AccDeleted  bool
}
type Response struct {
	Status     string `json:"Status"`
	StatusCode string `json:"StatusCode"`
	Message    string `json:"Message"`
	Data       DBAccountData
}
type TaskResponse struct {
	Status     string `json:"Status"`
	StatusCode string `json:"StatusCode"`
	Message    string `json:"Message"`
	Data       DbTaskData
}
type MTaskResponse struct {
	Status     string `json:"Status"`
	StatusCode string `json:"StatusCode"`
	Message    string `json:"Message"`
	Data       []DbTaskData
}
type MUserResponse struct {
	Status     string `json:"Status"`
	StatusCode string `json:"StatusCode"`
	Message    string `json:"Message"`
	Data       []DBAccountData
}

type DbTaskData struct {
	Id          string
	Name        string
	Description string
	State       string
}

type MultiTaskDB struct {
	Data []DbTaskData
}


type MultiUserDB struct {
	Data []DBAccountData
}

func SuccessResponse(w http.ResponseWriter, r *http.Request, message string, data string) {
	fmt.Println(message)
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(http.StatusOK)
	resp := make(map[string]string)
	resp["status"] = "Success"
	resp["statusCode"] = "200"
	resp["message"] = message
	resp["data"] = data
	jsonResp, err := json.Marshal(resp)
	if err != nil {
		log.Fatalf("Error happened in JSON marshal. Err: %s", err)
	}
	w.Write(jsonResp)
	return
}

func SingleUserResponse(w http.ResponseWriter, r *http.Request, message string, data string) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(http.StatusOK)

	if data != "" {
		var respData DBAccountData
		err := json.Unmarshal([]byte(data), &respData)
		if err != nil {
			log.Fatalf("Error happened in JSON marshal. Err: %s", err)
		}
		genericResp := Response{
			Status:     "Success",
			StatusCode: "200",
			Message:    message,
			Data: DBAccountData{
				AccName:     respData.AccName,
				AccPassword: respData.AccPassword,
				AccEmail:    respData.AccEmail,
				AccDeleted:  respData.AccDeleted,
			},
		}
		finalResp, err := json.Marshal(genericResp)
		if err != nil {
			log.Fatalf("Error happened in JSON marshal. Err: %s", err)
		}
		w.Write(finalResp)
		return
	} else {
		resp := make(map[string]string)
		resp["Status"] = "Bad Response"
		resp["StatusCode"] = "400"
		resp["Message"] = message
		resp["Data"] = ""
		jsonResp, err := json.Marshal(resp)
		if err != nil {
			log.Fatalf("Error happened in JSON marshal. Err: %s", err)
		}
		w.Write(jsonResp)
		return
	}
}
func SingleTaskResponse(w http.ResponseWriter, r *http.Request, message string, data string) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(http.StatusOK)

	if data != "" {
		var respData DbTaskData
		err := json.Unmarshal([]byte(data), &respData)
		if err != nil {
			log.Fatalf("Error happened in JSON marshal. Err: %s", err)
		}
		genericResp := TaskResponse{
			Status:     "Success",
			StatusCode: "200",
			Message:    message,
			Data: DbTaskData{
				Id:          respData.Id,
				Name:        respData.Name,
				Description: respData.Description,
				State:       respData.State,
			},
		}
		finalResp, err := json.Marshal(genericResp)
		if err != nil {
			log.Fatalf("Error happened in JSON marshal. Err: %s", err)
		}
		w.Write(finalResp)
		return
	} else {
		resp := make(map[string]string)
		resp["Status"] = "Bad Response"
		resp["StatusCode"] = "400"
		resp["Message"] = message
		resp["Data"] = ""
		jsonResp, err := json.Marshal(resp)
		if err != nil {
			log.Fatalf("Error happened in JSON marshal. Err: %s", err)
		}
		w.Write(jsonResp)
		return
	}
}
func MultipleTaskResponse(w http.ResponseWriter, r *http.Request, message string, data string) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(http.StatusOK)
	var respData MultiTaskDB
	err := json.Unmarshal([]byte(data), &respData)
	if err != nil {
		log.Fatalf("Error happened in JSON marshal. Err: %s", err)
	}

	genericResp := MTaskResponse{
		Status:     "Success",
		StatusCode: "200",
		Message:    message,
		Data:       respData.Data,
	}
	finalResp, err := json.Marshal(genericResp)
	if err != nil {
		log.Fatalf("Error happened in JSON marshal. Err: %s", err)
	}
	w.Write(finalResp)
	return
}
func MultipleUserResponse(w http.ResponseWriter, r *http.Request, message string, data string) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(http.StatusOK)
	var respData MultiUserDB
	err := json.Unmarshal([]byte(data), &respData)
	if err != nil {
		log.Fatalf("Error happened in JSON marshal. Err: %s", err)
	}

	genericResp := MUserResponse{
		Status:     "Success",
		StatusCode: "200",
		Message:    message,
		Data:       respData.Data,
	}
	finalResp, err := json.Marshal(genericResp)
	if err != nil {
		log.Fatalf("Error happened in JSON marshal. Err: %s", err)
	}
	w.Write(finalResp)
	return
}
func BadResponse(w http.ResponseWriter, r *http.Request, message string, data string) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(http.StatusBadRequest)
	resp := make(map[string]string)
	resp["Status"] = "Bad Response"
	resp["StatusCode"] = "400"
	resp["Message"] = message
	resp["Data"] = ""
	jsonResp, err := json.Marshal(resp)
	if err != nil {
		log.Fatalf("Error happened in JSON marshal. Err: %s", err)
	}
	w.Write(jsonResp)
	return
}
