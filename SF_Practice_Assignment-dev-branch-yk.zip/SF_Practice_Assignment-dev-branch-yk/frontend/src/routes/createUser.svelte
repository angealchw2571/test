<script>
    //Packages
    import axios from 'axios';
    import { goto } from '$app/navigation';
    
    //Components
    import Button from '../components/shared/Button.svelte';

    
    //Variables
    let fields = { username: '', password: '', email: ''};
    let errors = { username: '', password: '', email: ''};
    let success = "";

    let valid = false;

    const submitHandler = async () => {
        valid = true;
        // validate username
        if (fields.username.trim().length === 0 ) {
            valid = false;
            errors.username = 'Username cannot be empty';
        } else {
            errors.username = '';
        }
        // validate password
        if (fields.password.trim().length === 0) {
            valid = false;
            errors.password = 'Password cannot be empty';
        } else {
            errors.password = '';
        }
        // validate email
        if (fields.email.trim().length === 0) {
            valid = false;
            errors.email = 'Email cannot be empty';
        } else {
            errors.email = '';
        }
    
        if(valid) {
            //console.log(fields)
            //axios
            try {
                const res = await axios
                    .post(`http://${import.meta.env.VITE_DOMAIN_NAME}:${import.meta.env.VITE_SERVICE_PORT_USER}/api/createuser`, fields, {
                        headers: {
                            Accept: '*/*',
                            'Content-Type': 'application/json'
                        }
                    })
                if(res.status == 200) {
                    success = "Successfully created a new user."; 
                } else {
                    console.log(res);
                }
            } catch (err) {
                console.log(err.response.data.Message);
                if(err.response.data.Message.includes("Username")) {errors.username = err.response.data.Message;}
            }
        }  
    }
</script>

<div class="container">
    <h1>New User</h1>
    <form on:submit|preventDefault={submitHandler}>
        <label for="username"><b>Username</b></label>
        <input type="text" placeholder="Username" name="username" id="username" bind:value={fields.username}>
        <span class="error">{ errors.username }</span><br>
    
        <label for="password"><b>Password</b></label>
        <input type="password" placeholder="Password" name="password" id="password" maxLength=10 bind:value={fields.password}>
        <span class="error">{ errors.password }</span><br>
    
        <label for="email"><b>Email</b></label>
        <input type="email" placeholder="Email" name="email" id="email" bind:value={fields.email}>
        <span class="error">{ errors.email }</span><br>
        <div class="success">{ success }</div><br>
        
        <Button type="secondary" flat="true">Create New User</Button>
        <button type="button" on:click={() => goto('/dashboard')} class="backbtn">Back</button><br>
    </form>
</div>

<style>
:global(.container, button, h1) {
    font-family: Arial, Helvetica, sans-serif;
}

:global(.error) {
    color: #d91b42;
}

:global(.success) {
    color: #45c496;
}

:global(.backbtn) {
    background-color: black;
    color: white;
    font-weight: bold;
    width: 100%;
}
</style>