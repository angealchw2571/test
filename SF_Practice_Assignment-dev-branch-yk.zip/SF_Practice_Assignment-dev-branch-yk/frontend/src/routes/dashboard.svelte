<script>
    import TaskList from "./taskList.svelte";
</script>
<TaskList />