<script>
    import axios from 'axios';
    import { onMount } from 'svelte';
    import Table from '../components/shared/Table.svelte';

    let userTableData;
    let error = "";

    onMount(async () => { 
        
        try {
        // const res = await axios.post(`http://localhost:8081/test`, {
        const res = await axios
            .get(`http://${import.meta.env.VITE_DOMAIN_NAME}:${import.meta.env.VITE_SERVICE_PORT_USER}/api/allusers`, {
                headers: {
                    Accept: '*/*',
                    'Content-Type': 'application/json'
                }
            })
            console.log('test')
        // console.log(res);
        // console.log(res.data)
        // console.log(res.data.Data)
        if(res.data.StatusCode == 200){
            console.log(res.data.Data);
            userTableData=res.data.Data;
        } else {
            console.log("ELSE STATEMENT",res);
        }
        } catch (err) {
            error = "Username or password is incorrect."
            console.log(err);
		}
    })
</script>

<h1>User List</h1>
<Table {userTableData}/>