<script>
	//Packages
	import axios from 'axios';
	import { goto } from '$app/navigation';

	//Components
	import Header from '../components/Header.svelte';
	import Footer from '../components/Footer.svelte';
	//import Form from '../components/shared/Form.svelte';
	import Button from '../components/shared/Button.svelte';
	import { onMount } from 'svelte';

	//Variables
	let inputs = [
		{ id: 1, label: 'Username', value: '', type: 'text', error: '' },
		{ id: 2, label: 'Password', value: '', type: 'Password', error: '' }
	];
	let error = "";
	// let action = 'post';

	//Functions
	onMount(async () => { 
        try {
        // const res = await axios.post(`http://localhost:8081/test`, {
			const res = await axios
            .get(`https://modern-seasnail-37.hasura.app/api/rest/getallusers`, {
                headers: {
                    Accept: '*/*',
                    'Content-Type': 'application/json',
					'x-hasura-admin-secret':'814WZcjYy8sBjxFLKipm0oZife58Mzq04kojlLx8JPEPufFWpjuWHTiQ1Kqxjsel',
                }
            })
        
        // console.log(res);
        // console.log(res.data)
        // console.log(res.data.Data)
		console.log(res);
        // if(res.data.StatusCode == 200){
            
        // } else {
        //     console.log("ELSE STATEMENT",res);
        // }
        } catch (err) {
            console.log(err);
		}
    })

	//Axios
	const submitHandler = async (e) => {
		let data = {
			username: e.target.username.value,
			password: e.target.password.value
		};

		// console.log(data);

        //Code to change data format from json to form-data
        // var formBody = [];
		// for (var property in data) {
		// 	var encodedKey = encodeURIComponent(property);
		// 	var encodedValue = encodeURIComponent(data[property]);
		// 	formBody.push(encodedKey + '=' + encodedValue);
		// }
		// formBody = formBody.join('&');
		// const res = await fetch(`http://${import.meta.env.VITE_DOMAIN_NAME}:${import.meta.env.VITE_DOMAIN_PORT}/hello`, {
		// 	method: 'POST',
		// 	headers: {
		// 		"content-type": "API-Key",
		// 	},
		// 	credentials: "include",
		// 	body: JSON.stringify({data})
		// })

		// const json = await res.json()
		// let result = JSON.stringify(json)
		// console.log(result)

		//axios
		try {
			// const res = await axios.post(`http://localhost:8081/test`, {
			const res = await axios
				.post(`http://${import.meta.env.VITE_DOMAIN_NAME}:${import.meta.env.VITE_SERVICE_PORT_USER}/api/login`, data, {
					headers: {
						Accept: '*/*',
						'Content-Type': 'application/json',
					},
					withCredentials: true		
				})

			console.log(res);

			if(res.status == 200)	
				goto(`/dashboard`);
			else
				console.log(res);

		} catch (err) {
			error = "Username or password is incorrect."
			//console.log(err);
		}
        

		
        //Solution to convert data into form data to be processed in backend.
		// var details = {
		// 	username: 'test@gmail.com',
		// 	password: 'Password!',
		// 	grant_type: 'password'
		// };

		// var formBody = [];
		// for (var property in details) {
		// 	var encodedKey = encodeURIComponent(property);
		// 	var encodedValue = encodeURIComponent(details[property]);
		// 	formBody.push(encodedKey + '=' + encodedValue);
		// }
		// formBody = formBody.join('&');

		// fetch('http://localhost:8081/api/login', {
		// 	method: 'POST',
		// 	headers: {
		// 		'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8'
		// 	},
		// 	body: formBody
		// });
	};
</script>

<!-- <main> 
     <div>
         <Form {inputs} {action} />
     </div>
 </main> -->
<Header />
    <main>
        <form on:submit|preventDefault={submitHandler}>
            <div class="form-field">
                <label for="username">Username:</label>
                <input type="text" name="username" />
            </div>
            <div class="form-field">
                <label for="password">Password:</label>
                <input type="password" name="password" />
            </div>
			<div class="error"> { error } </div>
			<br>
            <Button type="secondary" flat="true">Login</Button>
        </form>
    </main>
<Footer />

<style>
	main {
		max-width: 960px;
		margin: 40px auto;
	}
	form {
		width: 400px;
		margin: 0 auto;
		text-align: center;
	}

	.form-field {
		margin: 18px auto;
	}

	label {
		display: block;
		font-family: Arial, Helvetica, sans-serif;
		font-size: medium;
		margin: 10px auto;
		text-align: left;
	}

	input{
		font-family: Arial, Helvetica, sans-serif;
		font-size: medium;
		-webkit-padding: 0.4em 0;
		padding: 0.4em;
		margin: 0 0 0.5em 0;
		box-sizing: border-box;
		border: 1px solid #ccc;
		border-radius: 2px;
		width: 100%;
		border-radius: 6px;
	}

	input:disabled {
		color: #ccc;
	}

	.error {
		font-weight: bold;
		font-size: 16px;
		color: #d91b42;
	}
</style>