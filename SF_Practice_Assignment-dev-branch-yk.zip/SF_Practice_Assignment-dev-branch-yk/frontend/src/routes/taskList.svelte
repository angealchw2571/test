<script>
    import axios from 'axios';
    import { goto } from "$app/navigation";
    import { task } from '../stores/task';

    
    let tasks = [];
    let error = "";
    
    task.subscribe(data => {
        var sortOrder = ["OPEN","TODO", "DOING", "DONE", "CLOSE"];
        var backgroundColor = {
            OPEN: "green",
            TODO: "blue",
            DOING: "gold",
            DONE: "orange",
            CLOSE: "grey",
        };
        tasks = data.sort((a, b) => sortOrder.indexOf(a.State) - sortOrder.indexOf(b.State))
        .map((element) => ({
            ...element,
            backgroundColor: backgroundColor[element.State],
        }));
    })

</script>

<button type="button" class="btn1" on:click={() => goto('/createTask')}>Create Task</button>
<h1>All Tasks</h1>
    {#each tasks as task}
        <details>
            <!-- Header of accordion -->
                <summary style="background:{task.backgroundColor};">
                    {task.Id} 
                    <div style="position:relative;float:right;text-transform: uppercase;">
                        {task.State}
                    </div>
                </summary>
            <!-- Body of accordion (Start Block) -->
            {#each Object.entries(task) as [key, value], index (key)}
                <p>{key} : {value}</p>
            {/each}
            <p><a href="/editTask?task={task.Id}">Edit</a></p>
            <!-- Body of accordion (End Block) -->
        </details>
        <div>{error}</div>
    {/each}
<style>
    :global(h1) {
        font-family: Arial, Helvetica, sans-serif;
    }

    :global(.btn1) {
        background-color: pink;
        color: black;
        position: relative;
        vertical-align: middle;
        float: right;
    }
</style>