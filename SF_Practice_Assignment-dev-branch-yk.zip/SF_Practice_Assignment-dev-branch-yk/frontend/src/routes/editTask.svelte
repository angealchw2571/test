<script>
    import axios from 'axios';
    import { goto } from "$app/navigation";
    import { page } from '$app/stores';
    import { task } from '../stores/task'
    import Button from '../components/shared/Button.svelte';
    // import { onMount, onDestroy } from 'svelte';

    //Variables
    let fields = { taskid: '', taskname: '', taskdescription: '', status: ''};
    let errors = { taskid: '', taskname: '', taskdescription: '', status: ''};
    let success = "";
    let error = "";
    let valid = false;

    let stateOptions = ["OPEN","TODO","DOING","DONE","CLOSE"]

    const taskid = $page.url.searchParams.get("task");
    let selectedTask;
    
       selectedTask = $task.find(
          function foundTask(object) {
            return object.Id === taskid;
          }
       )
       console.log(selectedTask)
       fields.taskid = selectedTask.Id;
       fields.taskname = selectedTask.Name;
       fields.taskdescription = selectedTask.Description;
       fields.status = selectedTask.State;
    //console.log(taskid);

    // onMount(async () => { 
    //   try {
    //     // const res = await axios.post(`http://localhost:8081/taskid`, {
    //     const res = await axios
    //         .get(`http://${import.meta.env.VITE_DOMAIN_NAME}:${import.meta.env.VITE_SERVICE_PORT_TASK}/api/task?taskid=${taskid}`, {
    //             headers: {
    //                 Accept: '*/*',
    //                 'Content-Type': 'application/json'
    //             }
    //         })
        
    //     // console.log(res);
    //     // console.log(res.data)
    //     // console.log(res.data.Data)
    //     if(res.data.StatusCode == 200){
    //       //Transforming response to frontend variables.  
    //       console.log(res.data.Data);
    //         console.log("preupdated",fields)
           
    //         fields.taskid=res.data.Data.Id;
    //         fields.taskname=res.data.Data.Name;
    //         fields.taskdescription=res.data.Data.Description;
    //         fields.status=res.data.Data.State;

    //         console.log("updated",fields)
    //     } else {
    //         console.log("ELSE STATEMENT",res);
    //     }
    //     } catch (err) {
    //         error = "Error during fetching of data."
    //         //console.log(err);
		// }
    // })
   
  const submitHandler = async () => {

    console.log("Submit Handler:",fields)
    valid = true;
    success = "";
    console.log("field.status",fields.status)
    for (const field of Object.entries(fields)) {
      if (field[1].length === 0) {
        valid = false;
        errors[field[0]] = `${field[0]} cannot be empty.`;
      } else {
        errors[field[0]] = '';
      }
    }

    if (valid) {

      //axios
      try {
          console.log(fields);
          console.log(`http://${import.meta.env.VITE_DOMAIN_NAME}:${import.meta.env.VITE_SERVICE_PORT_TASK}/api/updatetask`)
          const res = await axios
            .post(`http://${import.meta.env.VITE_DOMAIN_NAME}:${import.meta.env.VITE_SERVICE_PORT_TASK}/api/updatetask`, fields, {
              headers: {
                Accept: '*/*',
                'Content-Type': 'application/json'
              }
            })
          
          if(res.status == 200)	{
            success = "Successfully updated a task."
          } else {
            console.log(res);
          }
      } catch (err) {console.log(err);}
    }
  }
</script>

<div class="container">
    <h1>Edit Task</h1>
    <form on:submit|preventDefault={submitHandler}>
        <label for="taskid"><b>Task ID</b></label>
        <input type="text" placeholder={fields.taskid} name="taskid" id="taskid" bind:value={fields.taskid}>
        <span class="error">{ errors.taskid }</span><br>

        <label for="taskname"><b>Task Name</b></label>
        <input type="text" placeholder={Object.values(fields)[1]} name="taskname" id="taskname" bind:value={fields.taskname}>
        <span class="error">{ errors.taskname }</span><br>

        <label for="taskdescription"><b>Task Description</b></label>
        <input type="text" placeholder={Object.values(fields)[2]} name="taskdescription" id="taskdescription" bind:value={fields.taskdescription}>
        <span class="error">{ errors.taskdescription }</span><br>

        <label for="status"><b>Task State</b></label>
        <select name="status" bind:value={fields.status}>
          {#each stateOptions as status}
            {#if status === fields.status}
              <option selected>{status}</option>
            {:else}
              <option>{status}</option>
            {/if}
          {/each}
        </select>
        <span class="error">{ errors.status }</span><br>
        <div class="success">{ success }</div>

        <Button type="secondary" flat="true">Edit Task</Button>
        <button type="button" on:click={() => goto('/dashboard')} class="backbtn">Back</button><br>
    </form>
</div>
