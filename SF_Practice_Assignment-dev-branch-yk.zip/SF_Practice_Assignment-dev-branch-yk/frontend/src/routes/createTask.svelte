<script>
  import axios from 'axios';
  import { goto } from '$app/navigation';

  //Components
  import Button from '../components/shared/Button.svelte';
  
  //Variables
  let fields = { taskid: '', taskname: '', taskdescription: '', status: ''};
  let errors = { taskid: '', taskname: '', taskdescription: '', status: ''};
  let success = "";
  
  let valid = false;
  let stateOptions = ["OPEN","TODO","DOING","DONE","CLOSE"]
  const submitHandler = async () => {
    //TODO need to add data and add backend endpoint
    valid = true;
    
    for (const field of Object.entries(fields)) {
      if (field[1].length === 0) {
        valid = false;
        errors[field[0]] = `${field[0]} cannot be empty.`;
      } else {
        errors[field[0]] = ''; 
      }
    }

    if (valid) {
      //console.log(fields)
      //axios
      try {
          const res = await axios
            .post(`http://${import.meta.env.VITE_DOMAIN_NAME}:${import.meta.env.VITE_SERVICE_PORT_TASK}/api/createtask`, fields, {
              headers: {
                Accept: '*/*',
                'Content-Type': 'application/json'
              }
            })
          
          if(res.status == 200)	{
            success = "Successfully created a new task."
          } else {
            console.log(res);
          }
      } catch (err) {console.log(err);}
    }
  }
</script>

<div class="container">
    <h1>New Task</h1>
    <form on:submit|preventDefault={submitHandler}>
      <label for="taskid"><b>Task ID</b></label>
      <input type="text" placeholder="Task ID" name="taskid" id="taskid" bind:value={fields.taskid}>
      <span class="error">{ errors.taskid }</span><br>

      <label for="taskname"><b>Task Name</b></label>
      <input type="text" placeholder="Task Name" name="taskname" id="taskname" bind:value={fields.taskname}>
      <span class="error">{ errors.taskname }</span><br>

      <label for="taskdescription"><b>Task Description</b></label>
      <input type="text" placeholder="Description" name="taskdescription" id="taskdescription" bind:value={fields.taskdescription}>
      <span class="error">{ errors.taskdescription }</span><br>

      <label for="status"><b>Task State</b></label>
      <select type="text" placeholder="State" name="status" id="status" bind:value={fields.status}>
      {#each stateOptions as state}
        <option>{state}</option>
      {/each}
      </select>
      <span class="error">{ errors.status }</span><br>
      <div class="success">{ success }</div><br>

      <Button type="secondary" flat="true">Create New Task</Button>
      <button type="button" on:click={() => goto('/dashboard')} class="backbtn">Back</button>
    </form>
</div>

<style>
  :global(.container, button, h1) {
    font-family: Arial, Helvetica, sans-serif;
  }
  
  :global(.error) {
    color: #d91b42;
  }

  :global(.success) {
    color: #45c496;
  }

  :global(.backbtn) {
    background-color: black;
    color: white;
    font-weight: bold;
    width: 100%;
  }
</style>