<script>
    export let type = 'primary';
    export let flat = false;
    export let inverse = false;
</script>

<button class={type} class:flat={flat} class:inverse={inverse}>
    <slot></slot>
</button>

<style>
    button {
        padding: 16px 20px;
        margin: 8px 0;
        border: none;
        cursor: pointer;
        width: 100%;
        font-weight: bold;
        border-radius: 6px;
        font-size: medium;
    }
    .primary {
        background: #d91b42;
        color:white;
    }
    .secondary {
        background: #45c496;
        color:white;
    }

    .flat {
        box-shadow: none;
    }

    .primary.inverse {
        color: #d91b42;
        background: white;
        border: 2px solid #d91b42;
    }

    .secondary.inverse {
        color: #45c496;
        background: white;
        border: 2px solid #45c496;
    }
</style>