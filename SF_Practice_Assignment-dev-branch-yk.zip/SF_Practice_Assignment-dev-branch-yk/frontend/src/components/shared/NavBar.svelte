<div class="navbar">
    <a href="/dashboard">Task Management System</a>
    <div class="dropdown">
      <button class="dropbtn">User Management
        <i class="fa fa-caret-down"></i>
      </button>
      <div class="dropdown-content">
        <a href="/userList">View Users</a>
        <a href="/createUser">Create New User</a>
      </div>
    </div>
    <a href="/" style="float:right">Logout</a>
</div>

<style>
  :global(.navbar) {
    font-family: Arial, Helvetica, sans-serif;
  }
</style>