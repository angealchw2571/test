<script>
    export let userTableData;

    userTableData = [
      {
        "Username" : "Sam",
        "Status" : "Active"
      },
      {
        "Username" : "John",
        "Status" : "Active"
      }
    ];
</script>

<body>
    <table>
      <thead>
        <tr>
            {#each Object.keys(userTableData[0]) as columnHeading}
              {#if !columnHeading.includes("Password")}
              <th>{columnHeading}</th>
              {/if}
            {/each}
        <tr/>
      </thead>
      <tbody>
        {#each userTableData as user}
          <tr>
            {#each Object.entries(user) as [key, value], index (key)}
              {#if !key.includes("Password")}
              <td>{value}</td>
              {/if}
            {/each}
          </tr>
        {/each}
    </tbody>
    </table>
  </body>  

<style>
table {
  font-family: Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

td, th {
  border: 1px solid #ddd;
  padding: 8px;
}

tr:nth-child(even){background-color: #f2f2f2;}

tr:hover {background-color: #ddd;}

th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  background-color: pink;
  color: black;
}
</style>

