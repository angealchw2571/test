package controllerUser

import (
	response "example.com/packages/responseTemplates"
	// "github.com/gorilla/sessions"
	"encoding/json"
	"log"
	"net/http"
	"os"
)

//var DomainURL = "http://localhost:8088/"
var DomainURL = ""

func InitializeController() {
	DomainURL = os.Getenv("API_URL");
}

func GetSingleUserHandler(w http.ResponseWriter, r *http.Request) {
	username := r.URL.Query()["username"]
	urlString := DomainURL + "api/getuser/" + username[0]

	resp, err := http.Get(urlString)
	if err != nil {
		log.Fatalln(err)
	}
	var respSingleUser MultiUserDB

	err = json.NewDecoder(resp.Body).Decode(&respSingleUser)
	if err != nil {
		panic(err)
	}
	if respSingleUser.Data[0].AccName == "" {
		response.SingleUserResponse(w, r, "Invalid User", "")
	} else {
		singleUserJSON, _ := json.Marshal(respSingleUser.Data[0])
		response.SingleUserResponse(w, r, "Found single user", string(singleUserJSON))
	}

	//!		Get single user

}

func GetAllUsersHandler(w http.ResponseWriter, r *http.Request) {

	// if !ValidateSession(w, r) {
	// 	fmt.Println("Validation failed")
	// } else {
	// 	fmt.Println("going to fetch all users now")
	// 	response.SuccessResponse(w, r, "Get all users success", "")
	// }

	urlString := DomainURL + "api/getallusers"
	var respUsers MultiUserDB
	resp, err := http.Get(urlString)
	if err != nil {
		log.Fatalln(err)
	}
	err = json.NewDecoder(resp.Body).Decode(&respUsers)
	if err != nil {
		panic(err)
	}

	responseUserJSON, _ := json.Marshal(respUsers)
	response.MultipleUserResponse(w, r, "Fetch all user success", string(responseUserJSON))

	//TODO 		Get all users
}