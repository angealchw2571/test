package controllerUser

type MultiUserDB struct {
	Data []DBAccountData
}
type DBAccountData struct {
	AccName     string
	AccPassword string
	AccEmail    string
	AccDeleted  bool
}
type Account struct {
	Username string
	Password string
	Email    string
}
