package main

import (
	// "encoding/json"
	"fmt"
	"log"
	"net/http"
	"regexp"
	"strconv"
	"sync"
	"time"

	"example.com/packages/controllers"
	"github.com/gorilla/sessions"
	"github.com/rs/cors"

	"github.com/joho/godotenv"
)

var store = sessions.NewCookieStore([]byte("testing"))

type ResponseCommands struct {
	key   string
	value bool
}

var (
	regexen = make(map[string]*regexp.Regexp)
	relock  sync.Mutex
)

func mustCompileCached(pattern string) *regexp.Regexp {
	relock.Lock()
	defer relock.Unlock()

	regex := regexen[pattern]
	if regex == nil {
		regex = regexp.MustCompile("^" + pattern + "$")
		regexen[pattern] = regex
	}
	return regex
}

func allowMethod(h http.HandlerFunc, method string) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {

		if method != r.Method {
			w.Header().Set("Allow", method)
			http.Error(w, "405 method not allowed", http.StatusMethodNotAllowed)
			return
		}
		h(w, r)
	}
}

func get(h http.HandlerFunc) http.HandlerFunc {
	return allowMethod(h, "GET")
}

func post(h http.HandlerFunc) http.HandlerFunc {
	return allowMethod(h, "POST")
}

func match(path, pattern string, vars ...interface{}) bool {
	regex := mustCompileCached(pattern)
	matches := regex.FindStringSubmatch(path)
	if len(matches) <= 0 {
		return false
	}
	for i, match := range matches[1:] {
		switch p := vars[i].(type) {
		case *string:
			*p = match
		case *int:
			n, err := strconv.Atoi(match)
			if err != nil {
				return false
			}
			*p = n
		default:
			panic("vars must be *string or *int")
		}
	}
	return true
}

func Serve(w http.ResponseWriter, r *http.Request) {
	var h http.Handler
	p := r.URL.Path
	switch {
		case match(p, "/api/test"):
		h = get(testfunc)
		case match(p, "/api/allusers"):
		h = get(controllerUser.GetAllUsersHandler)
	case match(p, "/api/login"):
		h = post(controllerUser.LoginHandler)
	case match(p, "/api/user"):
		h = get(controllerUser.GetSingleUserHandler)
	case match(p, "/api/createuser"):
		h = post(controllerUser.CreateUserHandler)
	default:
		http.NotFound(w, r)
		return
	}
	h.ServeHTTP(w, r)
}


func validationMiddleware(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		fmt.Println("validation middleware working ")
		next.ServeHTTP(w, r)
	})
}

func messageHandler(message string) http.Handler {

	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		http.SetCookie(w, &http.Cookie{
			Name:     `session`,
			Value:    "hello",
			Expires:  time.Now().Add(time.Hour),
			Path:     "/",
			Secure:   false, // Secure = false allow to access from js
			HttpOnly: true,
			SameSite: http.SameSiteLaxMode,
		})
		w.Write([]byte("hello"))
		// http.NotFound(w, r)
	})
}

func testfunc (w http.ResponseWriter, r *http.Request){
	fmt.Println("hello")
}

func main() {
	mux := http.NewServeMux()
	
	//===== Environment variables section ==========
	fmt.Printf("Loading environment variables...\n")
	enverr := godotenv.Load("../.env")
	if enverr != nil {
		log.Fatalf("Error loading .env file\n")
	}
	fmt.Printf("Environment variables loaded.\n")

	controllerUser.InitializeController()
	//===== End of Environment variables section =========

	mux.HandleFunc("/", Serve)

	c := cors.New(cors.Options{
		AllowedOrigins:   []string{"http://localhost:3000"},
		AllowCredentials: true,
	})

	handler := c.Handler(mux)
	fmt.Printf("Starting userAPI server at port 8080\n")
	log.Fatal(http.ListenAndServe(":8080", handler))
}
