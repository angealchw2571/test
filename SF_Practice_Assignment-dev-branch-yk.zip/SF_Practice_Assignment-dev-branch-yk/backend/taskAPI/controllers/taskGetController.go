package controllerTask

import (
	response "example.com/packages/responseTemplates"
	// "github.com/gorilla/sessions"
	"encoding/json"
	"log"
	"net/http"

	"os"
)

var DomainURL = ""

func InitializeController() {
	DomainURL = os.Getenv("API_URL");
}

func GetSingleTaskHandler(w http.ResponseWriter, r *http.Request) {
	taskid := r.URL.Query()["taskid"]
	urlString := DomainURL + "api/gettask/" + taskid[0]
	var responseTask dbTask

	resp, err := http.Get(urlString)
	if err != nil {
		log.Fatalln(err)
	}

	err = json.NewDecoder(resp.Body).Decode(&responseTask)
	if err != nil {
		panic(err)
	}

	if responseTask.Name == "" {
		response.BadResponse(w, r, "Invalid Task", "")
	} else {
		responseTaskJSON, _ := json.Marshal(responseTask)
		response.SingleTaskResponse(w, r, "Found Task Success", string(responseTaskJSON))
	}

	//* 		Get single task

}
func GetAllTaskHandler(w http.ResponseWriter, r *http.Request) {
	
	urlString := DomainURL + "api/getalltasks"
	var respTasks MultiTaskDB
	resp, err := http.Get(urlString)
	if err != nil {
		log.Fatalln(err)
	}

	err = json.NewDecoder(resp.Body).Decode(&respTasks)
	if err != nil {
		panic(err)
	}

	responseTaskJSON, _ := json.Marshal(respTasks)
	response.MultipleTaskResponse(w, r, "Fetch all task success", string(responseTaskJSON))

	//* 		Get all task

}