package controllerTask

type dbTask struct {
	Id          string
	Name        string
	Description string
	State       string
}
type MultiTaskDB struct {
	Data []dbTask
}

type Task struct {
	Taskid          string
	TaskName        string
	TaskDescription string
	Status          string
}