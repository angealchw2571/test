package controllerTask

import (
	"bytes"
	"encoding/json"
	"fmt"

	response "example.com/packages/responseTemplates"
	// "github.com/gorilla/sessions"
	// "golang.org/x/crypto/bcrypt"

	// "io/ioutil"
	"log"
	"net/http"
)

func CreateTaskHandler(w http.ResponseWriter, r *http.Request) {
	var nTask Task
	err := json.NewDecoder(r.Body).Decode(&nTask)
	if err != nil {
		panic(err)
	}

	urlGetString := DomainURL + "api/gettask/" + nTask.Taskid
	var responseTask dbTask

	getResp, err := http.Get(urlGetString)
	if err != nil {
		log.Fatalln(err)
	}

	err = json.NewDecoder(getResp.Body).Decode(&responseTask)
	if err != nil {
		panic(err)
	}

	if responseTask.Id == nTask.Taskid{
		response.BadResponse(w, r, "Create Task Failed (ERR YACX3S)", "")
		return
	}



	urlString := DomainURL + "api/createTask"
	newTaskValues := map[string]string{"id": nTask.Taskid, "name": nTask.TaskName, "description": nTask.TaskDescription, "state": nTask.Status}
	json_data, err := json.Marshal(newTaskValues)
	if err != nil {
		log.Fatal(err)
	}

	resp, err := http.Post(urlString, "application/json",
		bytes.NewBuffer(json_data))
	if err != nil {
		log.Fatalln(err)
		response.BadResponse(w, r, "Create Task Failed (ERR DSD3SA)", "")
	} else {
		fmt.Println(resp)
		response.SuccessResponse(w, r, "Create Task Success", "")
	}

	//* 		Create Task
}
func UpdateTaskHandler(w http.ResponseWriter, r *http.Request) {

	var uTask Task
	err := json.NewDecoder(r.Body).Decode(&uTask)
	if err != nil {
		panic(err)
	}

	

	if uTask.Taskid == "" {
		response.BadResponse(w, r, "Invalid Task", "")
		return
	} else if uTask.TaskDescription == "" && uTask.Status == "" && uTask.TaskName == "" {
		response.BadResponse(w, r, "Invalid Parameters", "")
	} else {
		if uTask.TaskName != "" {
			urlString := DomainURL + "api/updatetaskname"
			updateTaskValues := map[string]string{"id": uTask.Taskid, "name": uTask.TaskName}
			json_data, err := json.Marshal(updateTaskValues)
			if err != nil {
				log.Fatal(err)
			}
			resp, err := http.Post(urlString, "application/json",
				bytes.NewBuffer(json_data))
			if err != nil {
				log.Fatalln(err)
				response.BadResponse(w, r, "Update Task Name Failed (ERR FDU35D)", "")
			} else {
				fmt.Println(resp)
				// response.SuccessResponse(w, r, "Update Task Name Success", "")
			}
		}
		if uTask.TaskDescription != "" {
			urlString := DomainURL + "api/updatetaskdescription"
			updateTaskValues := map[string]string{"id": uTask.Taskid, "description": uTask.TaskDescription}
			json_data, err := json.Marshal(updateTaskValues)
			if err != nil {
				log.Fatal(err)
			}

			resp, err := http.Post(urlString, "application/json",
				bytes.NewBuffer(json_data))
			if err != nil {
				log.Fatalln(err)
				response.BadResponse(w, r, "Update Task Name Failed (ERR 6653DK)", "")
			} else {
				fmt.Println(resp)
				// response.SuccessResponse(w, r, "Update Task Description Success", "")
			}
		}
		if uTask.Status != "" {
			urlString := DomainURL + "api/updatetaskstate"
			updateTaskValues := map[string]string{"id": uTask.Taskid, "state": uTask.Status}
			json_data, err := json.Marshal(updateTaskValues)
			if err != nil {
				log.Fatal(err)
			}

			resp, err := http.Post(urlString, "application/json",
				bytes.NewBuffer(json_data))
			if err != nil {
				log.Fatalln(err)
				response.BadResponse(w, r, "Update Task Name Failed (ERR FL24DS)", "")
			} else {
				fmt.Println(resp)
				// response.SuccessResponse(w, r, "Update Task Description Success", "")
			}
		}
		response.SuccessResponse(w, r, "Update Task Success", "")
	}

	//*			Update Task
}
func ResetPassHandler(w http.ResponseWriter, r *http.Request) {

	r.ParseForm()
	username := r.Form.Get("username")
	fmt.Println("username:", username)

	//TODO 		Reset password logic here

	response.SuccessResponse(w, r, "Reset password success", "")

	//TODO 		Reset password
}
func ChangePassHandler(w http.ResponseWriter, r *http.Request) {

	r.ParseForm()
	currentPassword := r.Form.Get("currentPass")
	newPassword := r.Form.Get("currentPass")
	fmt.Println("currentPass", currentPassword)
	fmt.Println("currentPass", newPassword)

	//TODO 		Change password logic here

	response.SuccessResponse(w, r, "Change password success", "")

	//TODO 		Change password
}
