package main

import (
	"encoding/json"
	"fmt"
	"io/ioutil"
	"log"
	"net/http"

	"accounts"
	"task"

	"github.com/joho/godotenv"
	"github.com/julienschmidt/httprouter"
)

func testDB_Accounts() {
	//test: accounts
	var dummy string = "pgx6"
	var dummy2 string = "pgxpgx"
	accounts.CreateAccount(dummy, dummy, "pgx@fake.com")
	accounts.GetAccountByName(dummy)
	accounts.UpdateAccountPassword(dummy, dummy2)
	accounts.DeleteAccount(dummy)
	accounts.GetAccountByName(dummy)
}

func testDB_Accounts_NonExistUser() {
	rname, rpassword, remail, rdeleted, rerr := accounts.GetAccountByName("sfvgewrvfvw")
	if rerr != nil {
		fmt.Printf("error getting account details of 'sfvgewrvfvw'.\n")
	}
	fmt.Printf("%s | %s | %s | %t\n", rname, rpassword, remail, rdeleted)
}

func testDB_Task() {
	var dummy string = "pgxtask1"
	var dummy2 string = "A task created using golang/pgx"
	var dummy3 string = "open"
	var dummy4 string = "todo"
	task.CreateTask(dummy, dummy, dummy3, "")
	rname, rid, rstate, rdescription, _ := task.GetTaskByID(dummy)
	fmt.Printf("%s | %s | %s | %s\n", rname, rid, rstate, rdescription)
	task.UpdateTaskDescription(dummy, dummy2)
	task.UpdateTaskState(dummy, dummy4)
	rname, rid, rstate, rdescription, _ = task.GetTaskByID(dummy)
	fmt.Printf("%s | %s | %s | %s\n", rname, rid, rstate, rdescription)
}

func testrouter_POST(w http.ResponseWriter, r *http.Request, ps httprouter.Params) {
	if err := r.ParseForm(); err != nil {
		fmt.Printf("ParseForm() err: %v", err)
		return
	}
	fmt.Printf("Post from website! r.PostFrom = %v\n", r.PostForm)

	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(http.StatusOK)
	resp := make(map[string]string)
	resp["status"] = "OK"
	resp["statusCode"] = "200"
	// resp["data"] = "some random data to marshal"
	// resp["data2"] = "some more random data to marshal"
	jsonResp, err := json.Marshal(resp)
	if err != nil {
		log.Fatalf("Error happened in JSON marshal. Err: %s", err)
	}
	fmt.Printf("jsonResp:\n%v\n", jsonResp)
	w.Write(jsonResp)
}

func testrouter_POSTJSON(w http.ResponseWriter, r *http.Request, ps httprouter.Params) {
	//We Read the response body on the line below.
	body, err := ioutil.ReadAll(r.Body)
	if err != nil {
		log.Fatalln(err)
	}
	//Convert the body to type string
	sb := string(body)
	fmt.Println(sb)
}

func main() {
	fmt.Printf("Loading environment variables...\n")
	enverr := godotenv.Load(".env")
	if enverr != nil {
		log.Fatalf("Error loading .env file\n")
	}
	fmt.Printf("Environment variables loaded.\n")

	accounts.AccountsEstablishConnection()
	defer accounts.AccountsClose()
	// testDB_Accounts()

	task.TaskEstablishConnection()
	defer task.TaskClose()
	// testDB_Task()

	router := httprouter.New()

	router.GET("/api/getuser/:name", accounts.APIGetAccount)
	router.GET("/api/getallusers", accounts.APIGetAllAccounts)
	router.POST("/api/createuser", accounts.APICreateAccount)

	router.GET("/api/gettask/:id", task.APIGetTask)
	router.GET("/api/getalltasks", task.APIGetAllTasks)
	router.POST("/api/createtask", task.APICreateTask)
	router.POST("/api/updatetaskname", task.APIUpdateTaskName)
	router.POST("/api/updatetaskdescription", task.APIUpdateTaskDescription)
	router.POST("/api/updatetaskstate", task.APIUpdateTaskState)

	router.POST("/api/testPOST", testrouter_POST)
	router.POST("/api/testPOSTJSON", testrouter_POSTJSON)

	fmt.Printf("dbServer listening at port 8088.\n")
	log.Fatal(http.ListenAndServe(":8088", router))
}
