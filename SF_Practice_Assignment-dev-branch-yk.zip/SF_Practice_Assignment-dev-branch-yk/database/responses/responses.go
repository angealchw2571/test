// TODO: make functions that construct different responses.
// package responses

// import (
// 	"encoding/json"
// 	"fmt"
// 	"log"
// 	"net/http"

// 	"github.com/julienschmidt/httprouter"
// )

// func HTTPResponseSuccess(w http.ResponseWriter, )