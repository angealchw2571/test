package task

type sTaskDetails struct {
	Id          string `json:"id"`
	Name        string `json:"name"`
	Description string `json:"description"`
	State       string `json:"state"`
}

type sAllTasksResponse struct {
	Status     string `json:"Status"`
	StatusCode string `json:"StatusCode"`
	Message    string `json:"Message"`
	Data       []sTaskDetails
}
