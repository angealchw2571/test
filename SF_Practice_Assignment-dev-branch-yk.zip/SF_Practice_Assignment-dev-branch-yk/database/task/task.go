package task

import (
	"context"
	"fmt"
	"os"

	"github.com/jackc/pgtype"
	"github.com/jackc/pgx/v4/pgxpool"
)

var dbpool *pgxpool.Pool
var ctx = context.Background()

func TaskEstablishConnection() (int, error) {
	var err error
	//dbpool, err := pgxpool.Connect(context.Background(), os.Getenv("DATABASE_URL"))
	urlExample := "postgres://postgres:" + os.Getenv("DATABASE_PASSWORD") + "@localhost:5432/tmsysdb"
	dbpool, err = pgxpool.Connect(context.Background(), urlExample)
	if err != nil {
		fmt.Fprintf(os.Stderr, "1564fds Unable to connect to database: %v\n", err)
		return -1, err
		//os.Exit(1)
	}
	return 0, err
}

func TaskClose() {
	dbpool.Close()
}

/*
Creates a task with the given name, id and state. Note that "name" is more like a short descriptive summary of the task, while "id" is the actual **unique** id of the task
*/
func CreateTask(name string, id string, state string, description string) error {
	var rid string
	row := dbpool.QueryRow(ctx, "INSERT INTO tmsys.task(\"name\", \"id\", \"state\", \"description\") VALUES($1, $2, $3, $4) RETURNING \"id\";", name, id, state, description)
	err := row.Scan(&rid)
	if err != nil {
		fmt.Fprintf(os.Stderr, "1asd115 error while creating task; %v\n", err)
	}
	return err
}

/*
Gets details of a task with given id. If there is an error (i.e. rerr != nil) then rname, rid, rstate and rdescription default to "".
*/
func GetTaskByID(id string) (rname string, rid string, rstate string, rdescription string, rerr error) {
	var tdescription pgtype.Text
	row := dbpool.QueryRow(ctx, "SELECT \"name\", \"id\", \"state\", \"description\" FROM tmsys.task WHERE \"id\" = $1;", id)
	rerr = row.Scan(&rname, &rid, &rstate, &tdescription)
	if rerr != nil {
		return "", "", "", "", rerr
	}
	if tdescription.Status == pgtype.Null {
		rdescription = ""
	} else {
		rdescription = tdescription.String
	}
	return rname, rid, rstate, rdescription, rerr
}

/*
Gets details of all tasks.
TODO: handle rainy day situations
*/
func GetAllTasks() (alltasks []sTaskDetails, rerr error) {
	rows, _ := dbpool.Query(ctx, "SELECT \"name\", \"id\", \"state\", \"description\" FROM tmsys.task;")
	var data sTaskDetails

	for rows.Next() {
		rerr = rows.Scan(&data.Name, &data.Id, &data.State, &data.Description)
		if rerr != nil {
			fmt.Fprintf(os.Stderr, "hntg165 error while scanning row; %v\n", rerr)
		}
		alltasks = append(alltasks, data)
	}
	return alltasks, rerr
}

/*
Updates the name of a task with given id
*/
func UpdateTaskName(id string, name string) error {
	var rid string
	row := dbpool.QueryRow(ctx, "UPDATE tmsys.task SET \"name\" = $2 WHERE \"id\" = $1 RETURNING \"id\";", id, name)
	err := row.Scan(&rid)
	if err != nil {
		fmt.Fprintf(os.Stderr, "321dsew error while updating task; %v\n", err)
	}
	return err
}

/*
Updates the state of a task with given id
*/
func UpdateTaskState(id string, state string) error {
	var rid string
	row := dbpool.QueryRow(ctx, "UPDATE tmsys.task SET \"state\" = $2 WHERE \"id\" = $1 RETURNING \"id\";", id, state)
	err := row.Scan(&rid)
	if err != nil {
		fmt.Fprintf(os.Stderr, "658fefh error while updating task; %v\n", err)
	}
	return err
}

/*
Updates the description of a task with given id. A "description" describes the task in longer and fuller details than the "name".
*/
func UpdateTaskDescription(id string, description string) error {
	var rid string
	row := dbpool.QueryRow(ctx, "UPDATE tmsys.task SET \"description\" = $2 WHERE \"id\" = $1 RETURNING \"id\";", id, description)
	err := row.Scan(&rid)
	if err != nil {
		fmt.Fprintf(os.Stderr, "fv215hr error while updating task; %v\n", err)
	}
	return err
}

// In asgn specs, delete not allowed
// func DeleteTask(name string) error {
// 	var id int
// 	row := dbpool.QueryRow(ctx, "UPDATE tmsys.task SET \"deleted\" = 'true' WHERE \"name\" = $1 RETURNING \"id\";", name)
// 	err := row.Scan(&id)
// 	if err != nil {
// 		fmt.Fprintf(os.Stderr, "error while 'deleting' user; %v\n", err)
// 	}
// 	return err
// }
