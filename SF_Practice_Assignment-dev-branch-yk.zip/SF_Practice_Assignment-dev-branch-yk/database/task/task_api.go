package task

import (
	"encoding/json"
	"fmt"
	"log"
	"net/http"

	"github.com/julienschmidt/httprouter"
)

/*
API for POST create task endpoint
TODO: handle rainy day situations
*/
func APICreateTask(w http.ResponseWriter, r *http.Request, _ httprouter.Params) {
	fmt.Println("APICreateTask request landed")
	var data sTaskDetails
	err := json.NewDecoder(r.Body).Decode(&data)
	if err != nil {
		fmt.Println("7845das error", err)
		w.Header().Set("Content-Type", "application/json")
		w.WriteHeader(http.StatusInternalServerError)
		resp := make(map[string]string)
		resp["status"] = "Internal Server Error"
		resp["statusCode"] = "500"
		jsonResp, err := json.Marshal(resp)
		if err != nil {
			log.Fatalf("174qwds Error happened in JSON marshal. Err: %s", err)
		}
		// fmt.Printf("\njsonResp:\n%v\n", jsonResp)
		w.Write(jsonResp)
		return
	}

	err = CreateTask(data.Name, data.Id, data.State, data.Description)
	if err != nil {
		fmt.Printf("9623sac error occurred creating task %s; %s\n", data.Id, err)
		w.Header().Set("Content-Type", "application/json")
		w.WriteHeader(http.StatusInternalServerError)
		resp := make(map[string]string)
		resp["status"] = "Internal Server Error"
		resp["statusCode"] = "500"
		jsonResp, err := json.Marshal(resp)
		if err != nil {
			log.Fatalf("5641srt Error happened in JSON marshal. Err: %s", err)
		}
		// fmt.Printf("\njsonResp:\n%v\n", jsonResp)
		w.Write(jsonResp)
		return
	}

	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(http.StatusCreated)
	resp := make(map[string]string)
	resp["status"] = "Created"
	resp["statusCode"] = "201"
	jsonResp, err := json.Marshal(resp)
	if err != nil {
		log.Fatalf("21sdq25 Error happened in JSON marshal. Err: %s", err)
	}
	// fmt.Printf("\njsonResp:\n%v\n", jsonResp)
	w.Write(jsonResp)
}

/*
API for GET get task endpoint
TODO: handle rainy day situations
*/
func APIGetTask(w http.ResponseWriter, r *http.Request, ps httprouter.Params) {
	fmt.Println("APIGetTask request landed")
	id := ps.ByName("id")
	// fmt.Println("GET request: RESTGetAccount - ", userid)

	rname, rid, rstate, rdescription, rerr := GetTaskByID(id)
	fmt.Printf("%s\t|%s\t|%s\t|%s\n", rname, rid, rstate, rdescription)

	if rerr != nil {
		fmt.Printf("dfwf423 error occurred getting %s; %s\n", rname, rerr)
	}

	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(http.StatusOK)
	resp := make(map[string]string)
	resp["status"] = "Success"
	resp["statusCode"] = "200"
	resp["Id"] = rid
	resp["Name"] = rname
	resp["Description"] = rdescription
	resp["State"] = rstate
	jsonResp, err := json.Marshal(resp)
	if err != nil {
		log.Fatalf("135425f Error happened in JSON marshal. Err: %s", err)
	}
	//fmt.Printf("jsonResp:\n%v\n", jsonResp)
	w.Write(jsonResp)
}

/*
API for GET get all tasks endpoint
TODO: handle rainy day situations
*/
func APIGetAllTasks(w http.ResponseWriter, r *http.Request, ps httprouter.Params) {
	fmt.Println("APIGetAllTasks request landed")

	w.Header().Set("Content-Type", "application/json")

	alltasks, rerr := GetAllTasks()

	if rerr != nil {
		resp := sAllTasksResponse{
			Status:     "Internal Server Error",
			StatusCode: "500",
			Message:    "Could not get all tasks",
			Data:       []sTaskDetails{},
		}
		finalResp, err := json.Marshal(resp)
		if err != nil {
			log.Fatalf("1364asd Error happened in JSON marshal. Err: %s", err)
		}
		w.WriteHeader(http.StatusInternalServerError)
		w.Write(finalResp)
		return
	}

	fmt.Printf("1464etg\n%v\n", alltasks)

	resp := sAllTasksResponse{
		Status:     "OK",
		StatusCode: "200",
		Message:    "Get All Tasks",
		Data:       alltasks,
	}
	finalResp, err := json.Marshal(resp)
	if err != nil {
		log.Fatalf("321456s Error happened in JSON marshal. Err: %s", err)
	}
	w.WriteHeader(http.StatusOK)
	w.Write(finalResp)
}

/*
API for POST update task name endpoint
TODO: handle rainy day situations
*/
func APIUpdateTaskName(w http.ResponseWriter, r *http.Request, _ httprouter.Params) {
	fmt.Println("APIUpdateTaskName request landed")
	var data sTaskDetails
	err := json.NewDecoder(r.Body).Decode(&data)
	if err != nil {
		fmt.Println("8435jmy error", err)
		w.Header().Set("Content-Type", "application/json")
		w.WriteHeader(http.StatusInternalServerError)
		resp := make(map[string]string)
		resp["status"] = "Internal Server Error"
		resp["statusCode"] = "500"
		jsonResp, err := json.Marshal(resp)
		if err != nil {
			log.Fatalf("3556hmj Error happened in JSON marshal. Err: %s", err)
		}
		// fmt.Printf("\njsonResp:\n%v\n", jsonResp)
		w.Write(jsonResp)
		return
	}
	//fmt.Printf("\n4897ftt %v\n", data)
	err = UpdateTaskName(data.Id, data.Name)
	if err != nil {
		fmt.Printf("6164mko error occurred creating task %s; %s\n", data.Id, err)
		w.Header().Set("Content-Type", "application/json")
		w.WriteHeader(http.StatusInternalServerError)
		resp := make(map[string]string)
		resp["status"] = "Internal Server Error"
		resp["statusCode"] = "500"
		jsonResp, err := json.Marshal(resp)
		if err != nil {
			log.Fatalf("7189uer Error happened in JSON marshal. Err: %s", err)
		}
		// fmt.Printf("\njsonResp:\n%v\n", jsonResp)
		w.Write(jsonResp)
		return
	}

	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(http.StatusOK)
	resp := make(map[string]string)
	resp["status"] = "OK"
	resp["statusCode"] = "200"
	jsonResp, err := json.Marshal(resp)
	if err != nil {
		log.Fatalf("4646reg Error happened in JSON marshal. Err: %s", err)
	}
	// fmt.Printf("\njsonResp:\n%v\n", jsonResp)
	w.Write(jsonResp)
}

/*
API for POST update task description endpoint
TODO: handle rainy day situations
*/
func APIUpdateTaskDescription(w http.ResponseWriter, r *http.Request, _ httprouter.Params) {
	fmt.Println("APIUpdateTaskDescription request landed")
	var data sTaskDetails
	err := json.NewDecoder(r.Body).Decode(&data)
	if err != nil {
		fmt.Println("4532ebb error", err)
		w.Header().Set("Content-Type", "application/json")
		w.WriteHeader(http.StatusInternalServerError)
		resp := make(map[string]string)
		resp["status"] = "Internal Server Error"
		resp["statusCode"] = "500"
		jsonResp, err := json.Marshal(resp)
		if err != nil {
			log.Fatalf("8794fwf Error happened in JSON marshal. Err: %s", err)
		}
		// fmt.Printf("\njsonResp:\n%v\n", jsonResp)
		w.Write(jsonResp)
		return
	}
	//fmt.Printf("\n4897ftt %v\n", data)
	err = UpdateTaskDescription(data.Id, data.Description)
	if err != nil {
		fmt.Printf("3461mkj error occurred creating task %s; %s\n", data.Id, err)
		w.Header().Set("Content-Type", "application/json")
		w.WriteHeader(http.StatusInternalServerError)
		resp := make(map[string]string)
		resp["status"] = "Internal Server Error"
		resp["statusCode"] = "500"
		jsonResp, err := json.Marshal(resp)
		if err != nil {
			log.Fatalf("8520uyt Error happened in JSON marshal. Err: %s", err)
		}
		// fmt.Printf("\njsonResp:\n%v\n", jsonResp)
		w.Write(jsonResp)
		return
	}

	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(http.StatusOK)
	resp := make(map[string]string)
	resp["status"] = "OK"
	resp["statusCode"] = "200"
	jsonResp, err := json.Marshal(resp)
	if err != nil {
		log.Fatalf("3257rww Error happened in JSON marshal. Err: %s", err)
	}
	// fmt.Printf("\njsonResp:\n%v\n", jsonResp)
	w.Write(jsonResp)
}

/*
API for POST update task state endpoint
TODO: handle rainy day situations
*/
func APIUpdateTaskState(w http.ResponseWriter, r *http.Request, _ httprouter.Params) {
	fmt.Println("APIUpdateTaskState request landed")
	var data sTaskDetails
	err := json.NewDecoder(r.Body).Decode(&data)
	if err != nil {
		fmt.Println("defd231 error", err)
		w.Header().Set("Content-Type", "application/json")
		w.WriteHeader(http.StatusInternalServerError)
		resp := make(map[string]string)
		resp["status"] = "Internal Server Error"
		resp["statusCode"] = "500"
		jsonResp, err := json.Marshal(resp)
		if err != nil {
			log.Fatalf("ukyj879 Error happened in JSON marshal. Err: %s", err)
		}
		// fmt.Printf("\njsonResp:\n%v\n", jsonResp)
		w.Write(jsonResp)
		return
	}
	//fmt.Printf("\n4897ftt %v\n", data)
	err = UpdateTaskState(data.Id, data.State)
	if err != nil {
		fmt.Printf("asda359 error occurred creating task %s; %s\n", data.Id, err)
		w.Header().Set("Content-Type", "application/json")
		w.WriteHeader(http.StatusInternalServerError)
		resp := make(map[string]string)
		resp["status"] = "Internal Server Error"
		resp["statusCode"] = "500"
		jsonResp, err := json.Marshal(resp)
		if err != nil {
			log.Fatalf("hyrh162 Error happened in JSON marshal. Err: %s", err)
		}
		// fmt.Printf("\njsonResp:\n%v\n", jsonResp)
		w.Write(jsonResp)
		return
	}

	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(http.StatusOK)
	resp := make(map[string]string)
	resp["status"] = "OK"
	resp["statusCode"] = "200"
	jsonResp, err := json.Marshal(resp)
	if err != nil {
		log.Fatalf("myyh330 Error happened in JSON marshal. Err: %s", err)
	}
	// fmt.Printf("\njsonResp:\n%v\n", jsonResp)
	w.Write(jsonResp)
}
