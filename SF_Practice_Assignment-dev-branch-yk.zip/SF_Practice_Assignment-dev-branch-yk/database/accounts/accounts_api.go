package accounts

import (
	"encoding/json"
	"fmt"
	"log"
	"net/http"

	"github.com/julienschmidt/httprouter"
)

/*
API for POST create account endpoint.
The request sends data in JSON
TODO: handle rainy day situations
TODO: find out why hashed passwords sent from back end end up different when parsed here
*/
func APICreateAccount(w http.ResponseWriter, r *http.Request, _ httprouter.Params) {
	fmt.Println("APICreateAccount request landed")
	var data sCreateAccountDetails
	err := json.NewDecoder(r.Body).Decode(&data)
	fmt.Printf("5653fds creation password is\n%s\n", data.Password)
	if err != nil {
		fmt.Println("error", err)
		w.Header().Set("Content-Type", "application/json")
		w.WriteHeader(http.StatusInternalServerError)
		resp := make(map[string]string)
		resp["status"] = "Internal Server Error"
		resp["statusCode"] = "500"
		jsonResp, err := json.Marshal(resp)
		if err != nil {
			log.Fatalf("Error happened in JSON marshal. Err: %s", err)
		}
		// fmt.Printf("\njsonResp:\n%v\n", jsonResp)
		w.Write(jsonResp)
		return
	}

	err = CreateAccount(data.Name, data.Password, data.Email)
	if err != nil {
		fmt.Printf("error occurred creating user %s; %s\n", data.Name, err)
		w.Header().Set("Content-Type", "application/json")
		w.WriteHeader(http.StatusInternalServerError)
		resp := make(map[string]string)
		resp["status"] = "Internal Server Error"
		resp["statusCode"] = "500"
		jsonResp, err := json.Marshal(resp)
		if err != nil {
			log.Fatalf("Error happened in JSON marshal. Err: %s", err)
		}
		// fmt.Printf("\njsonResp:\n%v\n", jsonResp)
		w.Write(jsonResp)
		return
	}

	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(http.StatusCreated)
	resp := make(map[string]string)
	resp["status"] = "Created"
	resp["statusCode"] = "201"
	jsonResp, err := json.Marshal(resp)
	if err != nil {
		log.Fatalf("Error happened in JSON marshal. Err: %s", err)
	}
	// fmt.Printf("\njsonResp:\n%v\n", jsonResp)
	w.Write(jsonResp)
}

/*
API for GET account endpoint.
TODO: handle rainy day situations
*/
func APIGetAccount(w http.ResponseWriter, r *http.Request, ps httprouter.Params) {
	fmt.Println("APIGetAccount request landed")
	userid := ps.ByName("name")
	// fmt.Println("GET request: RESTGetAccount - ", userid)

	rname, rpassword, remail, rdeleted, rerr := GetAccountByName(userid)
	fmt.Printf("%s\t|%s\t|%s\t|%t\n", rname, rpassword, remail, rdeleted)

	if rerr != nil {
		fmt.Printf("error occurred getting %s; %s\n", rname, rerr)
	}

	var allaccounts []sGetAccountDetails
	allaccounts = append(allaccounts, sGetAccountDetails{Name: rname, Password: rpassword, Email: remail, Deleted: rdeleted})

	if rerr != nil {
		resp := sAllAccountsResponse{
			Status:     "Internal Server Error",
			StatusCode: "500",
			Message:    "Could not get all users",
			Data:       []sGetAccountDetails{},
		}
		finalResp, err := json.Marshal(resp)
		if err != nil {
			log.Fatalf("3647adb Error happened in JSON marshal. Err: %s", err)
		}
		w.WriteHeader(http.StatusInternalServerError)
		w.Write(finalResp)
		return
	}

	resp := sAllAccountsResponse{
		Status:     "OK",
		StatusCode: "200",
		Message:    "Get all users",
		Data:       allaccounts,
	}
	finalResp, err := json.Marshal(resp)
	if err != nil {
		log.Fatalf("8496cds Error happened in JSON marshal. Err: %s", err)
	}
	w.WriteHeader(http.StatusOK)
	w.Write(finalResp)

	// w.Header().Set("Content-Type", "application/json")
	// w.WriteHeader(http.StatusOK)
	// resp := make(map[string]string)
	// resp["status"] = "Success"
	// resp["statusCode"] = "200"
	// resp["accname"] = rname
	// resp["accpassword"] = rpassword
	// resp["accemail"] = remail
	// if rdeleted == true {
	// 	resp["accdeleted"] = "true"
	// } else {
	// 	resp["accdeleted"] = "false"
	// }
	// jsonResp, err := json.Marshal(resp)
	// if err != nil {
	// 	log.Fatalf("Error happened in JSON marshal. Err: %s", err)
	// }
	// //fmt.Printf("jsonResp:\n%v\n", jsonResp)
	// w.Write(jsonResp)
}

/*
API for GET get all tasks endpoint
TODO: handle rainy days
*/
func APIGetAllAccounts(w http.ResponseWriter, r *http.Request, ps httprouter.Params) {
	fmt.Println("APIGetAllAccounts request landed")

	w.Header().Set("Content-Type", "application/json")

	allaccounts, rerr := GetAllAccounts()

	if rerr != nil {
		resp := sAllAccountsResponse{
			Status:     "Internal Server Error",
			StatusCode: "500",
			Message:    "Could not get all users",
			Data:       []sGetAccountDetails{},
		}
		finalResp, err := json.Marshal(resp)
		if err != nil {
			log.Fatalf("3647adb Error happened in JSON marshal. Err: %s", err)
		}
		w.WriteHeader(http.StatusInternalServerError)
		w.Write(finalResp)
		return
	}

	resp := sAllAccountsResponse{
		Status:     "OK",
		StatusCode: "200",
		Message:    "Get all users",
		Data:       allaccounts,
	}
	finalResp, err := json.Marshal(resp)
	if err != nil {
		log.Fatalf("8496cds Error happened in JSON marshal. Err: %s", err)
	}
	w.WriteHeader(http.StatusOK)
	w.Write(finalResp)
}

/*
 */
func APIUpdateAccount(w http.ResponseWriter, r *http.Request, _ httprouter.Params) {
	if err := r.ParseForm(); err != nil {
		fmt.Printf("ParseForm() err: %v", err)
		return
	}
	// fmt.Printf("Post from website! r.PostFrom = %v\n", r.PostForm)
}

/*
 */
func APIDeleteAccount(w http.ResponseWriter, r *http.Request, _ httprouter.Params) {
	if err := r.ParseForm(); err != nil {
		fmt.Printf("ParseForm() err: %v", err)
		return
	}
	// fmt.Printf("Post from website! r.PostFrom = %v\n", r.PostForm)
}
