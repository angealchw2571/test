package accounts

type sGetAccountDetails struct {
	Name     string `json:"accname"`
	Password string `json:"accpassword"`
	Email    string `json:"accemail"`
	Deleted  bool   `json:"accdeleted"`
}

type sCreateAccountDetails struct {
	Name     string `json:"name"`
	Password string `json:"password"`
	Email    string `json:"email"`
}

type sAllAccountsResponse struct {
	Status     string `json:"Status"`
	StatusCode string `json:"StatusCode"`
	Message    string `json:"Message"`
	Data       []sGetAccountDetails
}
