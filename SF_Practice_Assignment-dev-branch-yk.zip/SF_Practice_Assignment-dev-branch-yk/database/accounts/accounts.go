package accounts

import (
	"context"
	"fmt"
	"os"

	"github.com/jackc/pgx/pgtype"
	"github.com/jackc/pgx/v4/pgxpool"
)

var dbpool *pgxpool.Pool
var ctx = context.Background()

func AccountsEstablishConnection() (int, error) {
	var err error
	//dbpool, err := pgxpool.Connect(context.Background(), os.Getenv("DATABASE_URL"))
	urlExample := "postgres://postgres:" + os.Getenv("DATABASE_PASSWORD") + "@localhost:5432/tmsysdb"
	dbpool, err = pgxpool.Connect(context.Background(), urlExample)
	if err != nil {
		fmt.Fprintf(os.Stderr, "Unable to connect to database: %v\n", err)
		return -1, err
		//os.Exit(1)
	}
	return 0, err
}

func AccountsClose() {
	dbpool.Close()
}

/*
Create a user account with the given name, password and email strings
*/
func CreateAccount(name string, password string, email string) error {
	var id int
	row := dbpool.QueryRow(ctx, "INSERT INTO tmsys.accounts(\"name\", \"password\", \"email\") VALUES($1, $2, $3) RETURNING \"id\";", name, password, email)
	err := row.Scan(&id)
	if err != nil {
		fmt.Fprintf(os.Stderr, "error while creating user; %v\n", err)
	}
	return err
}

/*
Get details of a user account. If there is an error (i.e. rerr != nil) then rname, rpassword, remail default to "" while rdeleted defaults to true.
*/
func GetAccountByName(name string) (rname string, rpassword string, remail string, rdeleted bool, rerr error) {
	var temail pgtype.Text
	row := dbpool.QueryRow(ctx, "SELECT \"name\", \"password\", \"email\", \"deleted\" FROM tmsys.accounts WHERE \"name\" = $1;", name)
	rerr = row.Scan(&rname, &rpassword, &temail, &rdeleted)
	if rerr != nil {
		return "", "", "", true, rerr
	}
	if temail.Status == pgtype.Null {
		remail = ""
	} else {
		remail = temail.String
	}
	return rname, rpassword, remail, rdeleted, rerr
}

/*
Get details of all user accounts.
TODO: handle rainy day situations
*/
func GetAllAccounts() (allaccounts []sGetAccountDetails, rerr error) {
	rows, _ := dbpool.Query(ctx, "SELECT \"name\", \"password\", \"email\", \"deleted\" FROM tmsys.accounts;")
	var data sGetAccountDetails

	for rows.Next() {
		rerr = rows.Scan(&data.Name, &data.Password, &data.Email, &data.Deleted)
		if rerr != nil {
			fmt.Fprintf(os.Stderr, "hntg165 error while scanning row; %v\n", rerr)
		}
		allaccounts = append(allaccounts, data)
	}
	return allaccounts, rerr
}

/*
Updates password of a user account with given name.
*/
func UpdateAccountPassword(name string, password string) error {
	var id int
	row := dbpool.QueryRow(ctx, "UPDATE tmsys.accounts SET \"password\" = $2 WHERE \"name\" = $1 RETURNING \"id\";", name, password)
	err := row.Scan(&id)
	if err != nil {
		fmt.Fprintf(os.Stderr, "error while updating user; %v\n", err)
	}
	return err
}

/*
"Deletes" a user account with given name. User account data is still kept in the database.
*/
func DeleteAccount(name string) error {
	var id int
	row := dbpool.QueryRow(ctx, "UPDATE tmsys.accounts SET \"deleted\" = 'true' WHERE \"name\" = $1 RETURNING \"id\";", name)
	err := row.Scan(&id)
	if err != nil {
		fmt.Fprintf(os.Stderr, "error while 'deleting' user; %v\n", err)
	}
	return err
}
